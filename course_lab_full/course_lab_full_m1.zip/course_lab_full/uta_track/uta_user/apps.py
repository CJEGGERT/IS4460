from django.apps import AppConfig


class UtaUserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'uta_user'
