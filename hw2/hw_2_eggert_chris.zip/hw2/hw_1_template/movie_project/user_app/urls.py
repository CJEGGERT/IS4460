"""
URL configuration for movie_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.urls import path
from .views import MovieAddView,MovieDetailView,MovieListView, MovieLogin,MovieUpdateView, UserHome, MovieDeleteView

urlpatterns = [
    path('login/', MovieLogin.as_view(),name='movie-login'),
    path('user_home/', UserHome.as_view(),name='user-home'),
    path('movie_list/', MovieListView.as_view(),name='movie-list'),
    path('movie_detail/', MovieDetailView.as_view(),name='movie-detail'),
    path('movie_add/', MovieAddView.as_view(),name='movie-add'),
    path('movie_update/', MovieUpdateView.as_view(),name='movie-update'),
    path('movie_delete/', MovieDeleteView.as_view(),name='movie-delete'),
]
